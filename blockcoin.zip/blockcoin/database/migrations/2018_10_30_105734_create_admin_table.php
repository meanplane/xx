<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
/**
 * @xiaoer
 * 通用部分的数据表
 * 用户，组，菜单，权限，登录日志
 */
class CreateAdminTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //admin_user
        Schema::create('admin_user', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name',50)->nullable(false)->comment('用户名');
            $table->string('password',64)->nullable(false)->comment('密码');
            $table->string('email',125)->default('');
            $table->string('mobile',11);
            $table->string('realname',50)->default('')->comment('真实姓名');
            $table->tinyInteger('position_id')->default(0)->comment('部门');
            $table->tinyInteger('level')->default(1)->comment('职位');
            $table->tinyInteger('status')->default(1)->comment('1正常，2禁用');
            $table->string('remember_token',100)->default('');
            $table->tinyInteger('is_super')->default(0)->comment('超级管理员，有所有权限');
//            $table->timestamps();
            $table->integer('update_at');
            $table->integer('create_at');

            $table->index('name','idx_name');
        });

        // admin_group 用户组
        Schema::create('admin_group',function (Blueprint $t){
            $t->mediumInteger('id');
            $t->string('name',50)->nullable(false);
            $t->text('description');
            $t->text('menus')->comment('用户组拥有的规则id，多个用逗号隔开');
            $t->smallInteger('listorder')->default(0);
            $t->mediumInteger('admin_id')->default(0);

            $t->integer('update_at');
            $t->integer('create_at');

            $t->index('listorder','listorder');
        });

        // admin_group_access
        Schema::create('admin_group_access',function (Blueprint $t){
           $t->mediumInteger('admin_id')->comment('用户id');
           $t->mediumInteger('group_id')->comment('角色id');

           $t->unique(['admin_id','group_id'],'admin_group');
           $t->index('admin_id','admin');
           $t->index('group_id','group');
        });

        // admin_log
        Schema::create('admin_log',function (Blueprint $t){
            $t->increments('id');
            $t->mediumInteger('menu_id')->default(0)->comment('菜单id');
            $t->integer('primary_id')->default(0)->comment('表中主键id');
            $t->string('querystring',255)->default('')->comment('参数');
            $t->text('data')->comment('post数据');
            $t->string('ip',18)->default('');
            $t->mediumInteger('admin_id')->default(0);

            $t->integer('update_at');
            $t->integer('create_at');

            $t->index('menu_id','menu');
            $t->index('admin_id','admin');
            $t->index('create_at','create');
        });

        // admin_menu
        Schema::create('admin_menu',function(Blueprint $t){
           $t->mediumIncrements('id');
           $t->char('name')->default('')->comment('菜单名称');
           $t->mediumInteger('parentid')->default(0)->comment('上级菜单');
           $t->string('icon',20)->default('')->comment('图标');
           $t->string('m',20)->default('admin')->comment('模块module');
           $t->string('c',20)->default('')->comment('控制器controller');
           $t->string('a',20)->default('')->comment('方法action');
           $t->string('data',50);
           $t->string('group',50)->default('')->comment('分组');
           $t->smallInteger('listorder')->default(999);
           $t->tinyInteger('status')->default(1)->comment('1显示2不显示');
           $t->tinyInteger('write_log')->default(2)->comment('1记录2不记录');

           $t->integer('update_at');
           $t->integer('create_at');

           $t->index('listorder','listorder');
           $t->index('parentid','parentid');
           $t->index(['c','a'],'idx_a_c');
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('admin_user');
        Schema::dropIfExists('admin_group');
        Schema::dropIfExists('admin_group_access');
        Schema::dropIfExists('admin_log');
        Schema::dropIfExists('admin_menu');
    }
}
