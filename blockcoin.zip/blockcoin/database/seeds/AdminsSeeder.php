<?php

use Illuminate\Database\Seeder;

/**
 * @xiaoer
 * 用于生成初始化的 用户账号，组，菜单等数据
 */
class AdminsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //

    }
}
