<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Default Filesystem Disk
    |--------------------------------------------------------------------------
    |
    | Here you may specify the default filesystem disk that should be used
    | by the framework. The "local" disk, as well as a variety of cloud
    | based disks are available to your application. Just store away!
    |
    */

    'default' => env('FILESYSTEM_DRIVER', 'local'),

    /*
    |--------------------------------------------------------------------------
    | Default Cloud Filesystem Disk
    |--------------------------------------------------------------------------
    |
    | Many applications store files both locally and in the cloud. For this
    | reason, you may specify a default "cloud" driver here. This driver
    | will be bound as the Cloud disk implementation in the container.
    |
    */

    'cloud' => env('FILESYSTEM_CLOUD', 's3'),

    /*
    |--------------------------------------------------------------------------
    | Filesystem Disks
    |--------------------------------------------------------------------------
    |
    | Here you may configure as many filesystem "disks" as you wish, and you
    | may even configure multiple disks of the same driver. Defaults have
    | been setup for each driver as an example of the required options.
    |
    | Supported Drivers: "local", "ftp", "s3", "rackspace"
    |
    */

    'disks' => [

        'local' => [
            'driver' => 'local',
            'root' => base_path(),
        ],

        'public' => [
            'driver' => 'local',
            'root' => base_path(),
            'url' => env('APP_URL').'/upfiles',
            'visibility' => 'upfiles',
        ],

        's3' => [
            'driver' => 's3',
            'key' => env('AWS_KEY'),
            'secret' => env('AWS_SECRET'),
            'region' => env('AWS_REGION'),
            'bucket' => env('AWS_BUCKET'),
        ],
        'anchor'=>[
            'driver'=>'local',
            'root' =>storage_path('../public/anchor/'.date('Y-m-d'))
        ],

        'qiniu' => [
            'driver'  => 'qiniu',
            'domains' => [
                'default'   => 'pili-vod.whlive.top', //你的七牛域名
            ],
            'access_key'=> 'bXTKIddCVv-EuwEsNim6YoOVwHbHl8_aYslubYcP',  //AccessKey
            'secret_key'=> 'jEZ5kOTgump4JsOTtvgOpwJiTKOb7fo-4MMAOhPL',  //SecretKey
            'bucket'    => '3nbf6wgzs53sxxla4qw27sf6udgb3li0',  //Bucket名字
            'notify_url'=> '',  //持久化处理回调地址
        ],

    ],

];
