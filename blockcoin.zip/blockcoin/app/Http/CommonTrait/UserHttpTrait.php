<?php
/**
 * Created by IntelliJ IDEA.
 * User: xiaoer
 * Date: 2019/1/8
 * Time: 14:35
 */

namespace App\Http\CommonTrait;


trait UserHttpTrait
{
    use HttpTrait;

    /** 冻结/解冻 账号 POST
     * @params
     * 版本号 versionNo
     * 版本名 versionName
     * 描述 description
     * 下载地址 apkUrl
     * 应用类型 appType 1：安卓 2：苹果
     * 文件大小 size
     * @return
     * msg,code,data
     */
    public function user_freeze($params){
        return $this->common_http_post(env('JAVA_URL').$this->USER_FREEZE,$params);
    }
    private $USER_FREEZE = 'admin/user/freeze';

}