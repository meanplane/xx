<?php
/**
 * Created by IntelliJ IDEA.
 * User: xiaoer
 * Date: 2018/12/28
 * Time: 11:40
 */

namespace App\Http\CommonTrait;


trait WalletHttpTrait {
    use HttpTrait;

    /** 过渡钱包划转冷钱包 POST
     * @params
     * 钱包类型 walletType int POC 2, BTC 3, ETH 4, EOS 5, USDT 6
     * 过渡钱包公钥 fromPubKey String
     * 冷钱包公钥 toPubKey String
     *
     * @return
     * msg,code,data
     */
    public function transfer_cold_wallet($params){
        return $this->common_http_post(env('JAVA_URL').$this->TRANSFER_COLD_WALLET,$params);
    }
    private $TRANSFER_COLD_WALLET = 'admin/wallet/pool/cold/transfer';

    /** 修改冷钱包地址 POST
     * @params
     * 钱包类型 walletType int POC 2, BTC 3, ETH 4, EOS 5, USDT 6
     * 冷钱包公钥 publicKey String (eos 和 poc 传递钱包名称)
     *
     * @return
     * msg,code
     */
    public function edit_cold_wallet($params){
        return $this->common_http_post(env('JAVA_URL').$this->EDIT_COLD_WALLET,$params);
    }
    private $EDIT_COLD_WALLET = 'admin/wallet/pool/cold/save';


    /** 修改钱包配置 POST
     * @params
     * 钱包类型 walletType int POC 2, BTC 3, ETH 4, EOS 5, USDT 6
     * 提现矿工费 minerfee Double
     * 预警额度 outputWarn Double
     * 提现额度 outputLimit Double
     * 单笔提现限额 minTransfer Double·
     *
     * @return
     * msg,code
     */
    public function edit_wallet_settings($params){
        return $this->common_http_post(env('JAVA_URL').$this->EDIT_WALLET_SETTINGS,$params);
    }
    private $EDIT_WALLET_SETTINGS = 'admin/wallet/pool/type/save';

}