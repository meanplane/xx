<?php
/**
 * Created by IntelliJ IDEA.
 * User: xiaoer
 * Date: 2019/1/9
 * Time: 16:19
 */

namespace App\Http\CommonTrait;


trait StatusTrait
{
    //货币类型枚举
    public $COIN_TYPES = [
        1   =>   'RMBT',
        2   =>   'POC' ,
        3   =>   'BTC' ,
        4   =>   'ETH' ,
        5   =>   'EOS' ,
        6   =>  'USDT' ,
    ];

    // 货币对应精度（10进制）
    public $COIN_PRECISION = [
        1 => 2,
        2 => 4,
        3 => 8,
        4 => 18,
        5 => 4,
        6 => 8
    ];

    // 钱包日志状态 枚举
    public $LOG_STATUS = [0   =>  '待转账', 1   =>  '执行中', 2   =>  '待打包', 10  =>  '转账成功', -1  =>  '失败', -2  =>  '异常'];

    // 支付渠道
    public $PAY_TYPES = [1 => '支付宝', 2 => '微信'];

    // 服务费类型
    public $SERVER_FEE_TYPES = [4 => '挂单购买' , 5 => '挂单出售'];

    // 用户认证状态
    public $USER_APPROVE_STATUS = [1 => '已认证' , 2 => '未认证'];

    // 用户账户状态
    public $USER_ACCOUNT_STATUS = [1 => '正常' , 2 => '已冻结'];

    // 订单类型
    public $ORDER_TYPES = [1 => '购买' ,2 => '出售'];

    // 订单状态
    public $ORDER_STATUS = ['OPEN' => '待付款' ,'READY_FOR_DELIVERY' => '待放币'  ,'COMPLETED' => '交易完成','CANCELED'=>'取消交易','FREEZE' => '申诉中','WAITTING_FOR_VERIFY'=>'待审核','UNPASS_FOR_VERIFY'=>'审核未通过'];

    // 委托单类型
    public $ENTRUST_TYPES = [1 => '购买' ,2 => '出售'];

    //委托单状态
    public $ENTRUST_STATUS = ['OPEN' => '待付款' ,'READY_FOR_DELIVERY' => '待放币' ,'FREEZE' => '申诉中' ,'COMPLETED' => '交易完成','CANCELED'=>'取消交易','WAITTING_FOR_TRADE'=>'待下单','WAITTING_FOR_VERIFY'=>'待审核','UNPASS_FOR_VERIFY'=>'审核未通过'];

    // 申诉状态
    public $APPEAL_STATUS = ['UNPROCESS' => '未处理' ,'PROCESSING' => '处理中','PROCESSED'=>'已处理'];

    //审批状态
    public $APPROVAL_STATUS = ['UNPROCESS'=>'待审核','PASS_FOR_VERIFY'=>'审核通过','UNPASS_FOR_VERIFY'=>'审核未通过'];

    //预警原因  委托单
    public $WARNING_REASON_ENTRUST = [1=>'同一委托单下单频率过高'];

    //预警原因  订单
    public $WARNING_REASON_ORDER = [2=>'同一订单下单频率过高'];

    // 图片资源 前端类
    public $PIC_APP_TYPES = [1=>'WEB','2'=>'APPLE',3=>'ANDROID'];
}