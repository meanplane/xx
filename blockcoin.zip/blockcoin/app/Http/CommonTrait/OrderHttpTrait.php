<?php
/**
 * Created by IntelliJ IDEA.
 * User: xiaoer
 * Date: 2019/1/8
 * Time: 14:35
 */

namespace App\Http\CommonTrait;


trait OrderHttpTrait
{
    use HttpTrait;

//    /** 添加版本 POST
//     * @params
//     * 版本号 versionNo
//     * 版本名 versionName
//     * 描述 description
//     * 下载地址 apkUrl
//     * 应用类型 appType 1：安卓 2：苹果
//     * 文件大小 size
//     * @return
//     * msg,code,data
//     */
//    public function version_add($params){
//        return $this->common_http_post(env('JAVA_URL').$this->VERSION_ADD,$params);
//    }
//    private $VERSION_ADD = 'admin/version/add';

    /** 处理申述 POST
     * @params
     * 申述单号 orderCode
     * 事件类型 appealEvents
     * 备注  realAppealDescription
     * @return
     * msg,code,data
     */
    public function deal_appeal($params){
        return $this->common_http_post(env('JAVA_URL').$this->DEAL_APPEAL,$params);
    }
    private $DEAL_APPEAL = 'admin/cloudorder/processAppeal';

}