<?php
/**
 * Created by IntelliJ IDEA.
 * User: xiaoer
 * Date: 2018/12/28
 * Time: 11:20
 */
namespace App\Http\CommonTrait;

trait HttpTrait{

    public function common_http_get($url,$params){
        $client = new \GuzzleHttp\Client();

        try{
            $res = $client->request('GET',$url,
                [
                    'allow_redirects' => false,
                    'connect_timeout' => 1,
                    'timeout' => 1,
                    'verify'    =>  false,
                    'headers'   => [
                        'Accept' => 'application/json',
                    ],
                    'query' => $params
                ]
            );
        }catch (\Throwable $e){
//            dd($e->getMessage());
            return false;
        }
        return json_decode($res->getBody()->getContents(),true);
    }

    public function common_http_post($url,$params){
        $client = new \GuzzleHttp\Client();

        try{
            $res = $client->request('POST',$url,
                [
                    'allow_redirects' => false,
                    'connect_timeout' => 1,
                    'timeout' => 1,
                    'verify'    =>  false,
                    'headers'   => [
                        'content-type'=>'application/json'
                    ],
                    'body'  => json_encode($params)
                ]
            );
        }catch (\Throwable $e){
//            dd($e->getMessage());
//        dd($e->getMessage());
//            return false;
            return json_encode(['msg'=>$e->getMessage()],true);
        }
        return json_decode($res->getBody()->getContents(),true);
    }
}