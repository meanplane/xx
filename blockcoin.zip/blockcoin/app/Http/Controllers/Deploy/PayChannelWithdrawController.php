<?php
/**
 * Created by IntelliJ IDEA.
 * User: xiaoer
 * Date: 2019/1/10
 * Time: 11:44
 */

namespace App\Http\Controllers\Deploy;

use App\Http\CommonTrait\HttpTrait;
use App\Http\Controllers\Admin\Controller;
use Illuminate\Http\Request;

class PayChannelWithdrawController extends Controller{
    use HttpTrait;
    public function index(Request $request)
    {
        if(!$request->ajax())
            return $this->view();

        // 付费账号商户收款 配置
        $res = $this->common_http_post(env('JAVA_URL').'admin/paychannel/findSysPc',[
            'userName'=>'sys01'
        ]);
        return $res;
    }

    public function editChannel(Request $request){
        $data = $request->input('data');

        $res = $this->common_http_post(env('JAVA_URL').'admin/paychannel/modifySysPc',$data);
        return $res;
    }

}