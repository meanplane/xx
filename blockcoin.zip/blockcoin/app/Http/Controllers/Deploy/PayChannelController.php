<?php
/**
 * Created by IntelliJ IDEA.
 * User: xiaoer
 * Date: 2019/1/10
 * Time: 11:44
 */

namespace App\Http\Controllers\Deploy;

use App\Http\CommonTrait\HttpTrait;
use App\Http\CommonTrait\StatusTrait;
use App\Http\Controllers\Admin\Controller;
use Illuminate\Http\Request;

class PayChannelController extends Controller{
    use StatusTrait,HttpTrait;

    public function index()
    {
        $list_url = env('JAVA_URL').'admin/paychannel/list';
        $info_url = env('JAVA_URL').'admin/paychannel/findOne';
        $del_url = env('JAVA_URL').'admin/paychannel/delete';
        $pay_types = $this->PAY_TYPES;

        return $this->view(compact('list_url','pay_types','info_url','del_url'));
    }

    public function addChannel(Request $request){
        $data = $request->input('data');

        if(isset($data['channelName']) && $data['channelName'] == 'WX'){
            $keys = ['appId','publicKey','privateKey'];
            $data = array_filter($data,function($key) use($keys){
                 return !in_array($key,$keys);
            },ARRAY_FILTER_USE_KEY);
        }elseif(isset($data['channelName']) && $data['channelName'] == 'ALIPAY'){
            $keys = ['otcAppId','otcKey','otcMchId','walletAppId','walletKey','walletMchId'];
            $data = array_filter($data,function($key) use($keys){
                return !in_array($key,$keys);
            },ARRAY_FILTER_USE_KEY);
        }else{
            return ['code'=>0,'msg'=>'channelName错误！'];
        }

        $res = $this->common_http_post(env('JAVA_URL').'admin/paychannel/add',$data);
        return $res;
    }

    public function editChannel(Request $request){
        $data = $request->input('data');

        if(isset($data['channelName']) && $data['channelName'] == 'WX'){
            $keys = ['appId','publicKey','privateKey'];
            $data = array_filter($data,function($key) use($keys){
                return !in_array($key,$keys);
            },ARRAY_FILTER_USE_KEY);
        }elseif(isset($data['channelName']) && $data['channelName'] == 'ALIPAY'){
            $keys = ['otcAppId','otcKey','otcMchId','walletAppId','walletKey','walletMchId'];
            $data = array_filter($data,function($key) use($keys){
                return !in_array($key,$keys);
            },ARRAY_FILTER_USE_KEY);
        }else{
            return ['code'=>0,'msg'=>'channelName错误！'];
        }

        $res = $this->common_http_post(env('JAVA_URL').'admin/paychannel/update',$data);
        return $res;
    }

    public function delChannel(Request $request){

    }
}