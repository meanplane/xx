<?php
/**
 * Created by IntelliJ IDEA.
 * User: xiaoer
 * Date: 2018/12/26
 * Time: 13:54
 */


namespace App\Http\Controllers\Deploy;

use App\Http\CommonTrait\VersionHttpTrait;
use App\Http\Controllers\Admin\Controller;
use Illuminate\Http\Request;

class VersionController extends Controller
{
    use VersionHttpTrait;

    private $L ;
    public function __construct()
    {
        parent::__construct();
        $this->L = m('SettingsLog');
    }

    public function index()
    {
        $java_base_url = env('JAVA_URL');

        return $this->view(compact('java_base_url'));
    }

    public function addVersion(Request $request)
    {
        $data = $request->input('data');
        $res = $this->version_add($data);
        if(isset($res['code']) && $res['code'] == 1){
            //操作成功,写 log
//            foreach ($log_arr as $key => $log){
//                $this->L->create([
//                    'setting_type' => 1,
//                    'coin_type' => $data['walletType'],
//                    'user_id' => $this->login_user->id,
//                    'ip' => $request->getClientIp(),
//                    'opt' => '设置:'.$setting_names[$key].',从：'.$log['origin'].' 到：'.$log['edited']
//                ]);
//            }
            return [
                'code'=>1,
                'msg' => $res['msg']
            ];
        }
        return [
            'code'=>0,
            'msg' => $res
        ];
    }

    public function editVersion(Request $request)
    {
        $data = $request->input('data');
        $data['id'] = (int)$data['id'];
        $data['size'] = (int)$data['size'];

        $res = $this->version_edit($data);

        if(isset($res['code']) && $res['code'] == 1){
            //操作成功,写 log
//            foreach ($log_arr as $key => $log){
//                $this->L->create([
//                    'setting_type' => 1,
//                    'coin_type' => $data['walletType'],
//                    'user_id' => $this->login_user->id,
//                    'ip' => $request->getClientIp(),
//                    'opt' => '设置:'.$setting_names[$key].',从：'.$log['origin'].' 到：'.$log['edited']
//                ]);
//            }
            return [
                'code'=>1,
                'msg' => $res['msg']
            ];
        }
        return [
            'code'=>0,
            'msg' => $res['msg']
        ];
    }

}