<?php
/**
 * Created by IntelliJ IDEA.
 * User: xiaoer
 * Date: 2018/12/26
 * Time: 13:54
 */


namespace App\Http\Controllers\Deploy;

use App\Http\CommonTrait\StatusTrait;
use App\Http\CommonTrait\WalletHttpTrait;
use App\Http\Controllers\Admin\Controller;
use Illuminate\Http\Request;

class WithdrawPoolController extends Controller
{
    use WalletHttpTrait,StatusTrait;

    private $L ;
    public function __construct()
    {
        parent::__construct();
        $this->L = m('SettingsLog');
    }

    public function index()
    {
        $coin_types = $this->COIN_TYPES;
        $log_status = $this->LOG_STATUS;
        $java_base_url = env('JAVA_URL');

        return $this->view(compact('coin_types','log_status','java_base_url'));
    }

    public function editWalletSettings(Request $request){
        $setting_names = [
            'minerfee' => '提现矿工费',
            'outputWarn' => '预警额度',
            'outputLimit' => '提现额度',
            'minTransfer' => '单笔提现额度'
        ];

        $data = $request->input('data');
        $log_arr = [];

        // 对比原始值和修改值，记录log
        foreach ($data['origin'] as $key => $value){
            //数值化
            $data['origin'][$key] = floatval($value);
            $data['edited'][$key] = floatval($data['edited'][$key]);

            if($value != $data['edited'][$key]){
                $log_arr[$key] = [
                    'origin' => $value,
                    'edited' => $data['edited'][$key]
                ];
            }
        }

        if(count($log_arr) == 0 ){
            return ['code'=>0,'msg'=>'无任何修改!'];
        }

        $edit_data = [];
        foreach ($data['edited'] as $key => $value){
            $edit_data[$key] = pow(10,$data['numPrecision']) * $value;
        }
        $edit_data['walletType'] = intval($data['walletType']);

        $res = $this->edit_wallet_settings($edit_data);

        if(isset($res['code']) && $res['code'] == 1){
            //操作成功,写 log
            foreach ($log_arr as $key => $log){
                $this->L->create([
                    'setting_type' => 1,
                    'coin_type' => $data['walletType'],
                    'user_id' => $this->login_user->id,
                    'ip' => $request->getClientIp(),
                    'opt' => '设置:'.$setting_names[$key].',从：'.$log['origin'].' 到：'.$log['edited']
                ]);
            }
            return [
                'code'=>1,
                'msg' => $res['msg']
            ];
        }
        return [
            'code'=>0,
            'msg' => $res
        ];

    }
}