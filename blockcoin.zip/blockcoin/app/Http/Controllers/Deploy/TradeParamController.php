<?php
/**
 * Created by IntelliJ IDEA.
 * User: xiaoer
 * Date: 2019/1/10
 * Time: 11:44
 */

namespace App\Http\Controllers\Deploy;

use App\Http\CommonTrait\HttpTrait;
use App\Http\Controllers\Admin\Controller;
use Illuminate\Http\Request;

class TradeParamController extends Controller{

    use HttpTrait;
    public function index(Request $request)
    {
        if(!$request->ajax())
            return $this->view();

        $res = $this->common_http_post(env('JAVA_URL').'admin/dictionary/getDictionaryByCode',[
            'itemCode'=>'it.etoken.base.model.dictionary.TradeParams'
        ]);

        return $res;
    }

    public function editParam(Request $request){
        $data = $request->input('data');
        $data['itemCode']='it.etoken.base.model.dictionary.TradeParams';
        $res = $this->common_http_post(env('JAVA_URL').'admin/dictionary/modifyParams',$data);

        return $res;
    }

}