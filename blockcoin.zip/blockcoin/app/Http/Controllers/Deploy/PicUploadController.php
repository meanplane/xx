<?php
/**
 * Created by IntelliJ IDEA.
 * User: xiaoer
 * Date: 2018/12/26
 * Time: 13:54
 */

namespace App\Http\Controllers\Deploy;

use App\Http\CommonTrait\HttpTrait;
use App\Http\Controllers\Admin\Controller;
use Illuminate\Http\Request;

class PicUploadController extends Controller
{
    use HttpTrait;
    public function index()
    {
        $list_url = env('JAVA_URL').'admin/banner/list';
        $upload_url = env('PIC_UPLOAD_URL');
        $download_url = env('PIC_DOWNLOAD_URL');

        return $this->view(compact('list_url','upload_url','download_url'));
    }

    public function addBanner(Request $request){
        $data = $request->input('data',[]);
        $res = $this->common_http_post(env('JAVA_URL').'admin/banner/add',$data);
        return $res;
    }

    public function editBanner(Request $request){
        $data = $request->input('data');
        $res = $this->common_http_post(env('JAVA_URL').'admin/banner/update',$data);
        return $res;
    }

    public function delBanner(Request $request){
        $data = $request->input('data');
        $res = $this->common_http_post(env('JAVA_URL').'admin/banner/delete',$data);
        return $res;
    }

    public function moveBanner(Request $request){
        $data = $request->input('data');
        $res = $this->common_http_post(env('JAVA_URL').'admin/banner/move',$data);
        return $res;
    }

    public function topBanner(Request $request){
        $data = $request->input('data');
        $res = $this->common_http_post(env('JAVA_URL').'admin/banner/top',$data);
        return $res;
    }

}