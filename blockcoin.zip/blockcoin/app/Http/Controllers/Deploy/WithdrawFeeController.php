<?php
/**
 * Created by IntelliJ IDEA.
 * User: xiaoer
 * Date: 2019/1/10
 * Time: 11:44
 */

namespace App\Http\Controllers\Deploy;

use App\Http\Controllers\Admin\Controller;
use Illuminate\Http\Request;

class WithdrawFeeController extends Controller{

    public function index(Request $request)
    {
        if(!$request->ajax())
            return $this->view();

        return [
            'coin_prices'=>[
                ['name'=>'POC', 'price'=>20.00],
                ['name'=>'EOS', 'price'=>10.00]
            ],
            'pay_channels'=>[
                ['channel'=>'支付宝','way'=>'EOS/POC账号创建','app'=>'wallet'],
                ['channel'=>'微信','way'=>'EOS/POC账号创建','app'=>'wallet'],
            ],
        ];
    }

    public function editFee(Request $request){
//        dd($request->input('withdrawFee'));
        $withdrawFee = $request->input('withdrawFee');
//        $withdrawFee[0]['num'] = 999;
        return [
            'code' => 0,
            'data' => $withdrawFee,
            'msg' => 'xx'
        ];
    }

    public function editMinMax(){

    }

}