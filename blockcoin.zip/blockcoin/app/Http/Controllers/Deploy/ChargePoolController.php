<?php
/**
 * Created by IntelliJ IDEA.
 * User: xiaoer
 * Date: 2018/12/26
 * Time: 13:54
 */


namespace App\Http\Controllers\Deploy;

use App\Http\CommonTrait\StatusTrait;
use App\Http\CommonTrait\WalletHttpTrait;
use App\Http\Controllers\Admin\Controller;
use Illuminate\Http\Request;

class ChargePoolController extends Controller
{
    use WalletHttpTrait,StatusTrait;

    private $L ;
    public function __construct()
    {
        parent::__construct();
        $this->L = m('SettingsLog');
    }

    public function index()
    {
        $coin_types = $this->COIN_TYPES;
        $log_status = $this->LOG_STATUS;
        $java_base_url = env('JAVA_URL');

        return $this->view(compact('coin_types','log_status','java_base_url'));
    }

    // 修改冷钱包地址
    public function editColdWallet(Request $request){
        $data = [
            'walletType' => (int)$request->input('walletType'),
            'publicKey' => $request->input('publicKey')
        ];

        $res = $this->edit_cold_wallet($data);

        if(isset($res['code']) && $res['code'] == 1){
            //操作成功,写 log
            $this->L->create([
                'setting_type' => 0,
                'coin_type' => $request->input('walletType'),
                'user_id' => $this->login_user->id,
                'ip' => $request->getClientIp(),
                'opt' => '修改冷钱包地址,为：'.$request->input('publicKey')
            ]);
            return [
                'code'=>1,
                'msg' => $res['msg']
            ];
        }
        return [
            'code'=>0,
            'msg' => $res['msg']
        ];
    }

    // 转移至冷钱包
    public function transferColdWallet(Request $request){

        $data = [
            'walletType'=>(int)$request->input('walletType'),
            'fromPubKey'=>$request->input('fromPubKey'),
            'toPubKey'=>$request->input('toPubKey')
        ];

        $res = $this->transfer_cold_wallet($data);

        if(isset($res['code']) && $res['code'] == 1){
            //操作成功,写 log
            $this->L->create([
                'setting_type' => 0,
                'coin_type' => $request->input('walletType'),
                'user_id' => $this->login_user->id,
                'ip' => $request->getClientIp(),
                'opt' => '转移至冷钱包,从：'.$request->input('fromPubKey').' 到：'.$request->input('toPubKey')
            ]);
            return [
                'code'=>1,
                'msg' => $res['msg']
            ];
        }
        return [
            'code'=>0,
            'msg' => $res
        ];
    }

    // 设置操作日志
    public function settingsLog(Request $request){

        $where = [];
        $where[]=['s.setting_type',$request->input('setting_type')];
        $where[]=['s.coin_type',$request->input('coin_type')];

        $page = $request->input('page',1);
        $limit = $request->input('limit',20);

        $query = $this->L->from('settings_log as s')
            ->select('s.id','s.ip','s.opt','s.created_at','u.name','u.realname','ag.name as gname')
            ->leftJoin('admin_user as u','s.user_id','=','u.id')
            ->leftJoin('admin_group_access as aga','u.id','=','aga.admin_id')
            ->leftJoin('admin_group as ag','aga.group_id','=','ag.id')
            ->where($where)
            ->orderBy('s.created_at','desc');
        $count = $query->count();
        $data = $query->offset(($page-1)*$limit)
            ->limit($limit)
            ->get()->toArray();
        return ['code'=>1,'count'=>$count,'data'=>$data];
    }
}