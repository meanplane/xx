<?php
/**
 * Created by IntelliJ IDEA.
 * User: xiaoer
 * Date: 2019/1/10
 * Time: 11:44
 */

namespace App\Http\Controllers\Deploy;

use App\Http\Controllers\Admin\Controller;
use Illuminate\Http\Request;

class AppUrlController extends Controller{

    public function index(Request $request)
    {
        if(!$request->ajax())
            return $this->view();

        return [
        ];
    }

}