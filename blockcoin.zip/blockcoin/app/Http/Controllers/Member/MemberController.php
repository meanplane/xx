<?php

namespace App\Http\Controllers\Member;

use App\Http\CommonTrait\StatusTrait;
use App\Http\CommonTrait\UserHttpTrait;
use Illuminate\Http\Request;
use App\Http\Controllers\Admin\Controller;

class MemberController extends Controller
{
    use StatusTrait,UserHttpTrait;
    public $M,$A,$F,$ATO,$T;

    public function __construct()
    {
        parent::__construct();
        $this->M = m('Member');
        $this->A = m('Auth');
        $this->F = m('FundAccount');
    }


    //列表
    public function lists(Request $request)
    {
        $user_approve_status = $this->USER_APPROVE_STATUS;
        $user_account_status = $this->USER_ACCOUNT_STATUS;
        $coin_types = $this->COIN_TYPES;

        $charge_url = env('JAVA_URL').'admin/wallet/recharge';

        if(!$request->ajax()){
            return $this->view(compact('user_account_status','user_approve_status','coin_types','charge_url'));
        }

        // 分页
        $limit = $request->input('limit',10);
        $page = $request->input('page',1);

        $where = [];
        $wheres = [];
        $data = $request->input('data',[]);
        // 搜索 用户名，手机号，邮箱
        if(!empty($data['user_id'])){
            $where[] = ['userName', 'like',  '%' . $data['user_id'] . '%'];
            $wheres[] = ['email', 'like',  '%' . $data['user_id'] . '%'];
        }

//        // 认证状态
//        if($data['approve_status'] != -1){
//            $where[] = ['ex_auth.state',$data['approve_status']];
//        }

        // 账号状态
        if($data['account_status'] != -1){
            $where[] = ['ex_user.status',$data['account_status']];
        }

        // 未删除
        $where[] = ['ex_user.isDeleted',0];
        $query = $this->M
            ->leftjoin('ex_auth','ex_user.id','=','ex_auth.userId')
            ->select('ex_user.id','ex_user.nickname','ex_user.username','ex_user.phone','ex_user.email','ex_user.createdate','ex_auth.state as approve','ex_user.status')
            ->where($where)
            ->orWhere($wheres)
            ->orderBy('ex_user.id', 'desc');

        $count = $query->count();
        $res = $query->offset(($page-1)*$limit)
            ->limit($limit)
            ->get()->toArray();

        return ['code'=>1,'count'=>$count,'data'=>$res];
    }

    //详情
    public function info(Request $request)
    {
        $user_account_status = $this->USER_ACCOUNT_STATUS;
        $order_status = $this->ORDER_STATUS;
        $entrust_status = $this->ENTRUST_STATUS;
        $entrust_types = $this->ENTRUST_TYPES;

        //委托单列表
        $entrust_url = env('JAVA_URL') . 'admin/user/myagencylist';
        //订单单列表
        $order_url = env('JAVA_URL') . 'admin/user/mytradelist';

        $id = $request->input('id');//用户id
        //$where[] = ['status', '=', 1];

        $member = $this->M->where(['id'=>$id])->get()->toArray();
        $auth = $this->A->where(['userId'=>$id])->get()->toArray();

        //1表示银行卡，2表示支付宝，3表示微信
        $fund1 = $this->F->where(['userId'=>$id,'accountType'=>1])->get()->toArray();
        $fund2 = $this->F->where(['userId'=>$id,'accountType'=>2])->get()->toArray();
        $fund3 = $this->F->where(['userId'=>$id,'accountType'=>3])->get()->toArray();

        $info = array(
            'member'=>$member[0],
            'auth'=>$auth[0],
            'fund1'=>$fund1[0],
            'fund2'=>$fund2[0],
            'fund3'=>$fund3[0],
        );

        return $this->view(compact('info','user_account_status',
            'entrust_url','order_url',
            'entrust_status','order_status','entrust_types'));
    }

    // 用户冻结解冻
    public function checkState()
    {
        $param['status'] =  request('status');
        $param['userId'] =  request('id');

        $res = $this->user_freeze($param);

        if(isset($res['code']) && $res['code'] == 1){
            //操作成功,写 log
//            foreach ($log_arr as $key => $log){
//                $this->L->create([
//                    'setting_type' => 1,
//                    'coin_type' => $data['walletType'],
//                    'user_id' => $this->login_user->id,
//                    'ip' => $request->getClientIp(),
//                    'opt' => '设置:'.$setting_names[$key].',从：'.$log['origin'].' 到：'.$log['edited']
//                ]);
//            }
            return [
                'code'=>1,
                'msg' => $res['msg']
            ];
        }
        return [
            'code'=>0,
            'msg' => $res['msg']
        ];

    }
}
