<?php

namespace App\Http\Controllers\Order;

use App\Http\CommonTrait\StatusTrait;
use App\Http\Controllers\Admin\Controller;

class OrderController extends Controller
{
    use StatusTrait;

    public function lists()
    {
        $order_status = $this->ORDER_STATUS;
        $order_types = $this->ORDER_TYPES;
        $coin_types = $this->COIN_TYPES;
        $order_url = env('JAVA_URL').'admin/cloudorder/searchOrder';

        return $this->view(compact('order_status','order_types','coin_types','order_url'));
    }

    public function info()
    {
        $order_status = $this->ORDER_STATUS;
        $order_types = $this->ORDER_TYPES;

        $orderCode = request('id');
        $info_url = env('JAVA_URL') . 'admin/cloudorder/detail';

        return $this->view(compact('info_url','orderCode','order_status','order_types'));
    }
}
