<?php

namespace App\Http\Controllers\Entrust;

use App\Http\CommonTrait\StatusTrait;
use Illuminate\Http\Request;
use App\Http\Controllers\Admin\Controller;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;

class EntrustController extends Controller
{
    use StatusTrait;
    public function lists()
    {
        $entrust_status = $this->ENTRUST_STATUS;
        $entrust_types = $this->ENTRUST_TYPES;
        $coin_types = $this->COIN_TYPES;
        $entrust_url = env('JAVA_URL').'admin/cloudorder/searchOrder';

        return $this->view(compact('entrust_status','entrust_types','coin_types','entrust_url'));
    }


    public function info(Request $request)
    {
        $agencyOrderId = $request->input('id');//用户id
        $info_url = env('JAVA_URL') . 'admin/user/tradelist';

        $entrust_status = $this->ENTRUST_STATUS;
        $entrust_types = $this->ENTRUST_TYPES;

        $order_types = $this->ORDER_TYPES;
        $order_status = $this->ORDER_STATUS;

        return $this->view(compact('info_url','agencyOrderId','entrust_types','entrust_status','order_status','order_types'));
    }
}
