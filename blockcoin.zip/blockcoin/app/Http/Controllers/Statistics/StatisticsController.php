<?php

namespace App\Http\Controllers\Statistics ;

use App\Http\CommonTrait\StatusTrait;
use Illuminate\Http\Request;
use App\Http\Controllers\Admin\Controller;

class StatisticsController extends Controller
{

    use StatusTrait;
    public $M,$I,$O,$T;

    public function __construct()
    {
        parent::__construct();
        $this->M = m('CloudWalletAssetLog');
        $this->I = m('WalletInputLog');
        $this->O = m('WalletOutput');
        $this->T = m('WalletType');
    }

    //云端钱包对账
    public function checkStatistics()
    {
        // 获取货币精度
        $num_precision = $this->T->pluck('numPrecision','id')->toArray();
        $coin_types = $this->T->pluck('code','id')->toArray();
        $java_base_url = env('JAVA_URL');

        return $this->view(compact('java_base_url','num_precision','coin_types'));
    }

    //充值记录
    public function payList(Request $request)
    {
        $num_precision = $this->T->pluck('numPrecision','id')->toArray();
        $coin_types = $this->T->pluck('code','id')->toArray();

        if(!$request->ajax()){
            return $this->view(compact('num_precision','coin_types'));
        }

        // 分页
        $limit = $request->input('limit',10);
        $page = $request->input('page',1);

        $where = [];
        $data = $request->input('data',[]);

        $start_time =  $data['date_range'][0];
        $end_time =  $data['date_range'][1];
        $where[] = ['createDate', '>', $start_time];
        $where[] = ['createDate', '<', $end_time];
        $where[] = ['walletType',$data['coin_type']];
        $where[] = ['status', 10];//10表示充值成功

        $query = $this->I->where($where);

        $count = $query->count();
        $res = $query->offset(($page-1)*$limit)
            ->limit($limit)
            ->get()->toArray();

        $total= $this->I->where($where)->sum("money");

        return ['code'=>1,'count'=>$count,'data'=>$res,'total'=>$total];
    }



     // 提现记录
    public function withdrawList(Request $request)
    {
        $num_precision = $this->T->pluck('numPrecision','id')->toArray();
        $coin_types = $this->T->pluck('code','id')->toArray();
        $log_status = $this->LOG_STATUS;

        if(!$request->ajax()){
            return $this->view(compact('num_precision','coin_types','log_status'));
        }

        // 分页
        $limit = $request->input('limit',10);
        $page = $request->input('page',1);

        $where = [];
        $data = $request->input('data',[]);

        $start_time =  $data['date_range'][0];
        $end_time =  $data['date_range'][1];
        $where[] = ['createDate', '>', $start_time];
        $where[] = ['createDate', '<', $end_time];
        $where[] = ['walletType',$data['coin_type']];
        if($data['status'] != 99){
            $where[] = ['status', $data['status']];
        }

        $query = $this->O->where($where);

        $count = $query->count();
        $res = $query->offset(($page-1)*$limit)
            ->limit($limit)
            ->get()->toArray();

        $total= $this->O->where($where)->sum("money");

        return ['code'=>1,'count'=>$count,'data'=>$res,'total'=>$total];
    }


     // 服务费记录
    public function serviceList(Request $request)
    {
        $num_precision = $this->T->pluck('numPrecision','id')->toArray();
        $coin_types = $this->T->pluck('code','id')->toArray();
        $server_fee_types = $this->SERVER_FEE_TYPES;

        if(!$request->ajax()){
            return $this->view(compact('num_precision','coin_types','server_fee_types'));
        }

        // 分页
        $limit = $request->input('limit',10);
        $page = $request->input('page',1);

        $where = [];

        $data = $request->input('data',[]);

        $start_time =  $data['date_range'][0];
        $end_time =  $data['date_range'][1];
        $where[] = ['createTime', '>', $start_time];
        $where[] = ['createTime', '<', $end_time];
        $where[] = ['walletType',$data['coin_type']];
        if($data['server_fee'] != -1){
            $where[] = ['changeType', $data['server_fee']];
        }else{
            $whereIn = ['changeType' , [4,5]];
        }


        $query = $this->M->where($where)->whereNull('orderId')->whereNotNull('agencyOrderId');
        $total= $this->M->where($where)->whereNull('orderId')->whereNotNull('agencyOrderId')->sum("amount");

        if(isset($whereIn)){
            $query->whereIn($whereIn[0],$whereIn[1]);
            $total= $this->M->where($where)
                ->whereIn($whereIn[0],$whereIn[1])
                ->sum("amount");
        }

        $count = $query->count();
        $res = $query->offset(($page-1)*$limit)
            ->limit($limit)
            ->get()->toArray();

        return ['code'=>1,'count'=>$count,'data'=>$res,'total'=>$total];
    }
}
