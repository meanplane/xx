<?php

namespace App\Http\Controllers\Appeal;
use App\Http\CommonTrait\OrderHttpTrait;
use App\Http\CommonTrait\StatusTrait;
use App\Http\Controllers\Admin\Controller;

class AppealController extends Controller
{
    use StatusTrait,OrderHttpTrait;

    public function lists()
    {
        $appeal_status = $this->APPEAL_STATUS;
        $order_types = $this->ORDER_TYPES;
        $coin_types = $this->COIN_TYPES;

        $list_url = env('JAVA_URL').'admin/cloudorder/searchOrder';
        $info_url = env('JAVA_URL').'admin/cloudorder/detail';

        return $this->view(compact('appeal_status','order_types','coin_types','list_url','info_url'));
    }

    public function info()
    {
        $order_status = $this->ORDER_STATUS;
        $order_types = $this->ORDER_TYPES;

        $orderCode = request('orderCode');
        $info_url = env('JAVA_URL') . 'admin/cloudorder/detail';

        return $this->view(compact('info_url','orderCode','order_status','order_types'));
    }


     // 提交处理结果
    public function add()
    {
        $orderCode =  request('orderCode');
        $realAppealDescription =  request('realAppealDescription');
        $appealEvent =  request('appealEvent');

        $data = array(
            'orderCode'=>$orderCode,
            'realAppealDescription'=>$realAppealDescription,
            'appealEvent'=>$appealEvent,
        );
        $res = $this->deal_appeal($data);

        return $res;
    }




}
