<?php


namespace App\Http\Controllers\Risk;

use App\Http\CommonTrait\StatusTrait;
use Illuminate\Http\Request;
use App\Http\Controllers\Admin\Controller;

class RiskController extends Controller
{

    use StatusTrait;

    // 监控条件设置 page
    public function monitoring()
    {
        //1 订单
        $data = array(
            'type'=>1,
        );
        $url = env('JAVA_URL', 'http://192.168.88.37:8082/') . 'admin/orderParameter/getOrderParameter';
        $bool = https_requests($url,$data);
        $transaction =  $bool['data']['result'];
        
        //2 委托单
        $data = array(
            'type'=>2,
        );
        $url = env('JAVA_URL', 'http://192.168.88.37:8082/') . 'admin/orderParameter/getOrderParameter';
        $bool = https_requests($url,$data);
        $entrust =  $bool['data']['result'];

        $monitoring = array(
            'entrust'=>$entrust,
            'transaction'=>$transaction,
        );

        return $this->view(compact('monitoring'));
    }

     // 监控条件提交
    public function addMonitoring()
    {
        //1 订单
        $data = array(
            'type'=>1,
            'times'=> request('transaction_times'),
            'nums'=>request('transaction_nums')
        );
        $url = env('JAVA_URL') . 'admin/orderParameter/saveOrderParameter';
        $transaction = https_requests($url,$data);

        //2 委托单
        $data = array(
            'type'=>2,
            'times'=> request('entrust_times'),
            'nums'=>request('entrust_nums')
        );
        $url = env('JAVA_URL') . 'admin/orderParameter/saveOrderParameter';
        $entrust = https_requests($url,$data);

        if($transaction && $entrust){
            $data = [
                'entrust'=>$entrust,
                'transaction'=>$transaction
            ];
        }
        return $data;
    }

    // 待审核委托单
    public function entrustLists()
    {
        $entrust_types = $this->ENTRUST_TYPES;
        $approval_status = $this->APPROVAL_STATUS; // 审核状态
        $warning_reason = $this->WARNING_REASON_ENTRUST;
        $entrust_url = env('JAVA_URL') . 'admin/cloudorder/searchOrder';

        return $this->view(compact('approval_status','warning_reason','entrust_url','entrust_types'));
    }



    // 待审核订单
    public function orderLists()
    {

        $order_types = $this->ORDER_TYPES;
        $approval_status = $this->APPROVAL_STATUS;
        $warning_reason = $this->WARNING_REASON_ORDER;
        $order_url = env('JAVA_URL') . 'admin/cloudorder/searchOrder';

        return $this->view(compact('approval_status','warning_reason','order_url','order_types'));

    }


    // 订单状态提交
    public function checkOrder()
    {
//        $param['agencyOrderId'] =  request('agencyOrderId');
//        $param['type'] =  2;
//        $param['status'] =  request('status');
//        $url = env('JAVA_URL') . 'admin/order/processOrder';
//        $res = https_requests($url,$param);


        $param['orderCode'] =  request('orderCode');
        $param['type'] =  2;
        $param['event'] =  request('event');
        $url = env('JAVA_URL') . 'admin/order/processOrder';;
        $res = https_requests($url,$param);
        return $res;
//
//        if($bool['code'] == 1){
//            $data = [
//                'code' => '10001',
//                'msg'  => '操作成功',
//            ];
//        }else{
//            $data = [
//                'code' => '10002',
//                'msg'  => '操作失败',
//            ];
//        }
//        return $data;
        
    }


    // 委托单状态提交
    public function checkEntrust()
    {
        $param['agencyOrderId'] =  request('agencyOrderId');
        $param['type'] =  1;
        $param['status'] =  request('status');
        $url = env('JAVA_URL') . 'admin/order/processOrder';;
        $res = https_requests($url,$param);
        
        return $res;
    }
}
