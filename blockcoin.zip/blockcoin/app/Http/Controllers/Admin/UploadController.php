<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use zgldh\QiniuStorage\QiniuStorage;
class UploadController extends Controller
{

    public function index()
    {

        return $this->view(compact('index'));
    }



    /**
     * 上传文件到七牛
     * @author fancy
     * @param  Request $request [description]
     * @return [type]                            [description]
     */
    public function upload(Request $request)
    {
        // 判断是否有文件上传
        if ($request->hasFile('file')) {
            // 获取文件,file对应的是前端表单上传input的name
            $file = $request->file('file');

            // 初始化
            $disk = QiniuStorage::disk('qiniu');
            // 重命名文件
            $fileName = md5($file->getClientOriginalName() . time() . rand()) . '.' . $file->getClientOriginalExtension();

            // 上传到七牛
            $bool = $disk->put('iwanli/image_' . $fileName, file_get_contents($file->getRealPath()));
            //dump($disk);die();
            // 判断是否上传成功
            if ($bool) {
                $path = $disk->downloadUrl('iwanli/image_' . $fileName);

                $data = array(
                    'code' => '200',
                    'msg' => '上传成功',
                    'url' => $path
                );

                return $data;
            }
            $data = array(
                'code' => '10002',
                'msg' => '上传失败'
            );
            return $data;
        }

        $data = array(
            'code' => '10002',
            'msg' => '没有文件'
        );
        return $data;
    }


    /**
     * 上传文件到七牛base64
     * @author fancy
     * @param  Request $request [description]
     * @return [type]                            [description]
     */
    public function qiniu_upload(Request $request)
    {
        $resource = $request->input('imgs');
        // 判断是否有文件上传
        if ($resource) {
            $path = uploadQiNiu($resource, 'base64');
            if ($path) {
                $data = array(
                    'code' => 200,
                    'msg' => '上传成功',
                    'url' => $path
                );

                return $data;
            }
            $data = array(
                'code' => 10002,
                'msg' => '上传失败'
            );
            return $data;
        }

        $data = array(
            'code' => 10002,
            'msg' => '没有文件'
        );
        return $data;
    }
    
}



