<?php

/**
 * 自定义函数库
 * @filename  helpers
 * @author    fancy
 * @date      2017-8-9 17:08:32
 * @version   SVN:$Id:$
 */
function m($model)
{
    static $arr = [];
    $path = "\\App\\Models\\" . $model;
    if (!isset($arr[$path])) {
        $class = new ReflectionClass($path);
        $arr[$path] = $class->newInstance();
    }
    return $arr[$path];
}


/**
 * 数组转树
 * @param type $list
 * @param type $root
 * @param type $pk
 * @param type $pid
 * @param type $child
 * @return type
 */
function list_to_tree($list, $root = 0, $pk = 'id', $pid = 'parentid', $child = '_child')
{
    // 创建Tree
    $tree = array();
    if (is_array($list)) {
        // 创建基于主键的数组引用
        $refer = array();
        foreach ($list as $key => $data) {
            $refer[$data[$pk]] = &$list[$key];
        }
        foreach ($list as $key => $data) {
            // 判断是否存在parent
            $parentId = 0;
            if (isset($data[$pid])) {
                $parentId = $data[$pid];
            }
            if ((string)$root == $parentId) {
                $tree[] = &$list[$key];
            } else {
                if (isset($refer[$parentId])) {
                    $parent = &$refer[$parentId];
                    $parent[$child][] = &$list[$key];
                }
            }
        }
    }
    return $tree;
}

function node_tree($arr, $id = 0, $level = 0)
{
    static $array = array();
    foreach ($arr as $v) {
        if ($v['parentid'] == $id) {
            $v['level'] = $level;
            $array[] = $v;
            node_tree($arr, $v['id'], $level + 1);
        }
    }
    return $array;
}


/**
 * 发邮件
 * @param string $subject 主题
 * @param string $str 内容
 * @param string $to 收件人 多人以 逗号 分隔
 * @param string $attach 附件 多个以 逗号 分隔
 * @param string $blade 模板
 */
function send_mail($subject, $str, $to = '', $attach = '', $blade = 'emails.mail')
{
    if (!$to) {
        $to_arr = explode(',', config('mail.to_email'));
    } else {
        if (is_array($to)) {
            $to_arr = $to;
        } else {
            $to_arr = explode(',', $to);
        }
    }


    if ($attach) {
        if (is_array($attach)) {
            $attach_arr = $attach;
        } else {
            $attach_arr = explode(',', $attach);
        }
    }

    \Mail::send($blade, ['str' => $str], function ($message) use ($subject, $to_arr, $attach_arr) {

        $message->subject($subject . '[' . config('app.env') . ']');

        foreach ($to_arr as $mail) {
            $message->to($mail);
        }

        if (count($attach_arr) > 0) {
            foreach ($attach_arr as $file) {
                $message->attach($file);
            }
        }
    });
}


function arr2str($arr, $str = '')
{

    if (is_array($arr)) {
        foreach ($arr as $k => $v) {
            if (is_array($v)) {
                return arr2str($v, $str);
            } else {
                $str .= "<p>{$k}-->{$v}</p>";
            }
        }
    }
    return $str;
}


if (! function_exists('https_requests')) {

    //curl  请求
    function https_requests(string $url, $param, bool $header = true)
    {
        $header_options = [];
        if ($header) {
            $header_options = [
                'content-type: application/json',
            ];
        }

        $ch = curl_init();
        $post_param = json_encode($param);
        $curl_options = array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => 1, //返回原生的（Raw）输出
            CURLOPT_HEADER => 0,
            CURLOPT_TIMEOUT => 120, //超时时间
            CURLOPT_FOLLOWLOCATION => 1, //是否允许被抓取的链接跳转
            CURLOPT_HTTPHEADER => $header_options,
            CURLOPT_POST => 1, //POST
            CURLOPT_POSTFIELDS => $post_param, //post数据
            CURLOPT_ENCODING=>'gzip,deflate'
        );
        if (strpos($url,"https")!==false) {
            $curl_options[CURLOPT_SSL_VERIFYPEER] = false; // 对认证证书来源的检查
        }
        curl_setopt_array($ch, $curl_options);
        $res = curl_exec($ch);
        $data = json_decode($res, true);
        if(json_last_error() != JSON_ERROR_NONE){
            $data = $res;
        }
        curl_close($ch);
        return $data;
    }
}



/**
 * GET 请求
 * @param string $url
 */
if (! function_exists('https_get')) {
    function https_get($url)
    {
        //  echo $url;
        //初始化
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        //设置头文件的信息作为数据流输出
        curl_setopt($curl, CURLOPT_HEADER, 0);
        //设置获取的信息以文件流的形式返回，而不是直接输出。
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

        $curl_options = array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => 1, //返回原生的（Raw）输出
            CURLOPT_HEADER => 0,
            CURLOPT_TIMEOUT => 120, //超时时间
            CURLOPT_FOLLOWLOCATION => 1, //是否允许被抓取的链接跳转
            CURLOPT_POST => 0, //GET
            CURLOPT_ENCODING=>'gzip,deflate'
        );
        if (strpos($url,"https")!==false) {
            $curl_options[CURLOPT_SSL_VERIFYPEER] = false; // 对认证证书来源的检查
        }
        //执行命令
        curl_setopt_array($curl, $curl_options);
        $res = curl_exec($curl);
        $data = json_decode($res, true);
        if(json_last_error() != JSON_ERROR_NONE){
            $data = $res;
        }
        curl_close($curl);
        return $data;
    }
}



if (! function_exists('object_to_array')) {

    //对象转数组
    function object_to_array($obj) {
        $obj = (array)$obj;
        foreach ($obj as $k => $v) {
            if (gettype($v) == 'resource') {
                return;
            }
            if (gettype($v) == 'object' || gettype($v) == 'array') {
                $obj[$k] = (array)($v);
            }
        }
        return $obj;
    }

}




if (! function_exists('array2object')) {

    function array2object($array) {
        if (is_array($array)) {
            $obj = new StdClass();
            foreach ($array as $key => $val){
                $obj->$key = $val;
            }
        }
        else { $obj = $array; }
        return $obj;
    }

}
