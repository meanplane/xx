<?php

/**
 * 会员
 * @filename  Auth
 * @author    fancy
 * @date      2017-9-15 18:23:19
 * @version   SVN:$Id:$
 */


namespace App\Models;


class Auth extends Block
{
    protected $table = "ex_auth";
    public function getUpdatedAtColumn() {
        return null;
    }
}
