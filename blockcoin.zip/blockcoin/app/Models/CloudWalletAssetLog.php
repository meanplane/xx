<?php

/**
 * 平台参数配置
 * @filename  Deploy
 * @author    fancy
 * @date      2017-9-15 18:23:19
 * @version   SVN:$Id:$
 */


namespace App\Models;




class CloudWalletAssetLog extends Block
{
    protected $table = "cloud_wallet_asset_log";
}
