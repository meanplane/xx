<?php

/**
 * 会员
 * @filename  Member
 * @author    fancy
 * @date      2017-9-15 18:23:19
 * @version   SVN:$Id:$
 */


namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Storage extends Model
{
    protected $table = 'storage';

}
