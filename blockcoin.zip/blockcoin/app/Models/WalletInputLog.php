<?php

/**
 * 提现日志
 * @filename  WalletInputLog
 * @author    fancy
 * @date      2017-9-15 18:23:19
 * @version   SVN:$Id:$
 */


namespace App\Models;




class WalletInputLog extends Block
{
    protected $table = "ex_wallet_input_log";
}
