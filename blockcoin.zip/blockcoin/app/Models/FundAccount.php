<?php

/**
 *
 * @filename  FundAccount
 * @author    fancy
 * @date      2017-9-15 18:23:19
 * @version   SVN:$Id:$
 */


namespace App\Models;


class FundAccount extends Block
{
    protected $table = "ex_fund_account";
    public function getUpdatedAtColumn() {
        return null;
    }
}
