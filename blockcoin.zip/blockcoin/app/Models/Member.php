<?php

/**
 * 会员
 * @filename  Member
 * @author    fancy
 * @date      2017-9-15 18:23:19
 * @version   SVN:$Id:$
 */


namespace App\Models;


class Member extends Block
{
    protected $table = "ex_user";
}
