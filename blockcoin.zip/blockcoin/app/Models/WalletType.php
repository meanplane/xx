<?php

/**
 * 钱包数据类型转换
 * @filename  Deploy
 * @author    fancy
 * @date      2017-9-15 18:23:19
 * @version   SVN:$Id:$
 */


namespace App\Models;




class WalletType extends Block
{
    protected $table = "ex_wallet_type";
}
