<?php

/**
 * 会员
 * @filename  Member
 * @author    fancy
 * @date      2017-9-15 18:23:19
 * @version   SVN:$Id:$
 */


namespace App\Models;

use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redis;
use ZipArchive;
use Illuminate\Database\Eloquent\Model;

class Files extends Model
{
    protected $table = 'files';
    public $dateFormat = 'U';
    const UPLOAD_LIMIT = '1073741824';    // 1GB
    const DOWNLOAD_LIMIT = '157286400';    // 150MB
    const FOLDER_ICON = '/icon/folder.png';
    const OTHER_ICON = '/icon/unknown.png';
    public static $fileType = [
        2 => [  // 图片类型
            'jpg', 'jpeg', 'png', 'gif', 'bmp', 'pic', 'tif', 'tiff',
        ],
        3 => [  // 文档类型
            'txt', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'hlp', 'wps', 'rtf', 'html', 'pdf',
        ],
        4 => [  // 视频类型
            'avi', 'mpg', 'mov', 'swf', 'mp4',
        ],
        5 => [  // 音乐类型
            'wav', 'aif', 'au', 'mp3', 'ram', 'wma', 'mmf', 'flac',
        ],
        6 => [  // 种子类型
            'torrent'
        ],
    ];

    /**
     * 创建文件夹
     * @author linyc
     * @param  string    $name  目录名
     * @param  int       $uid  用户id
     * @param  int       $directory  父级目录名
     * @param  string    $firstCharacter  新建的文件夹的首字母
     * @param  bool      $isHidden  新建的文件夹的首字母
     * @return int       新建的文件夹的id
     */
    public function makeDir($name, $uid, $directory = 0, $firstCharacter, $isHidden = false)
    {
        $this->parent_name = '根目录';
        if ($directory) {
            $parentName = $this->where(['id' => $directory, 'disable' => 1, 'status' => 1])->value('original_name');
            if (!$parentName) {
                return -1;  // 父级目录不存在
            }
            $this->parent_name = $parentName;
        }
        $this->original_name = $this->getName($name, $uid, 1, '', $directory);
        $this->parent_id = $directory;
        $this->uid = $uid;
        $this->path = self::getEntirePath($directory ,$uid);
        $this->first_character = $firstCharacter;
        $this->file_type = 1;
        if ($isHidden) {
            $this->status = 2;
        }
        $this->point_time = date('Y-m-d H:m:s');
        $result = $this->save();
        if (!$result) {
            return -2;  // 创建目录失败
        }
        return $this->id;
    }

    /**
     * 创建文件记录
     * @author linyc
     * @param  string    $name 文件名
     * @param  int       $uid 用户id
     * @param  string    $ext 文件后缀名
     * @param  int       $size 文件大小
     * @param  string    $uploadType 上传类型
     * @param  string    $blockList 分片列表
     * @param  int       $directory 父级目录名
     * @param  int       $oid 离线下载任务id
     * @param  string    $offlineUrl 离线下载任务链接
     * @param  int       $index 种子文件内部的序号
     * @param  string    $firstCharacter   新建的文件夹的首字母
     * @return int       新建的文件记录的id
     */
    public function makeFile($name, $uid, $ext, $size, $uploadType, $firstCharacter, $blockList = '', $directory = 0, $oid = 0, $offlineUrl = '', $index = 0)
    {
        $ext = strtolower($ext);
        $this->parent_name = '根目录';
        if ($directory) {
            $parentName = $this->where(['id' => $directory, 'disable' => 1, 'status' => 1])->value('original_name');
            if (!$parentName) {
                return -1;  // 父级目录不存在
            }
            $this->parent_name = $parentName;
        }
        $fileType = self::getFileType($ext);
        $this->original_name = $this->getName($name, $uid, $fileType, $ext, $directory);
        $this->file_size = $size;
        $this->parent_id = $directory;
        $this->uid = $uid;
        $this->path = self::getEntirePath($directory ,$uid);
        $this->ext = $ext;
        $this->file_type = $fileType;
        $this->upload_type = $uploadType;
        $this->block_list = $blockList;
        $this->first_character = $firstCharacter;
        $this->oid = $oid;
        $this->offline_url = $offlineUrl;
        $this->point_time = date('Y-m-d H:m:s');
        $this->index = $index;
        $this->status = 2;  // 这里只创建文件记录，状态置为未上传完成，等上传操作完成后，修改这里的状态
        $result = $this->save();
        if (!$result) {
            return -2;  // 创建文件记录失败
        }
        return $this->id;
    }

    /**
     * 检查目录/文件名，获取不重复的名称
     * @author linyc
     * @param  string    $name 目录名或文件名
     * @param  int       $uid 用户id
     * @param  int       $fileType 文件类型，方便把没有后缀名的文件和文件夹区分开
     * @param  string    $ext 文件后缀名
     * @param  int       $directory 父级目录名
     * @return string
     */
    public function getName($name, $uid, $fileType, $ext, $directory)
    {
        $checkArray = $this->where(['parent_id' => $directory, 'uid' => $uid, 'file_type' => $fileType, 'ext' => $ext, 'disable' => 1, 'status' => 1, ['original_name', 'like', $name . '%']])->pluck('original_name')->toArray();
        $newName = self::checkName($name, $checkArray);
        return $newName;
    }

    /**
     * 检测文件名是否重复，重复则自动重命名
     * @author linyc
     * @param  string    $name 目录名或文件名
     * @param  array     $checkArray 用户id               
     * @return string
     */
    public static function checkName($name, $checkArray)
    {
        if (!in_array($name, $checkArray)) {  // 文件名不存在，直接返回
            return $name;
        }
        $temp = [];
        foreach ($checkArray as $v) {  // 取出可能占用重命名位置的文件名
            if (preg_match('/^' . $name . '(\([1-9]+[0-9]*\))?$/', $v)) {
                $temp[] = $v;
            }
        }
        $i = 1;
        $newName = '';
        while (true) {
            $newName = $name . '(' . $i . ')';
            if (!in_array($newName, $temp)) {
                break;
            }
            $i++;
        }
        return $newName;
    }

    /**
     * 压缩文件
     * @author linyc
     * @param  string    $name 压缩包名称
     * @param  array    $fileArray 多文件路径组成的数组
     * @return string
     */
    public static function zipFile($name, $fileArray)
    {
        $fileName = 'upload/' . $name;
        if (!preg_match('/\.zip$/', $name)) {
            $fileName = 'upload/' . $name . '.zip';
        }
        $zip = new ZipArchive();
        if ($zip->open($fileName, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) { //打开压缩包
             return -1;    // 创建压缩文件失败
        }

        $fileArray = array_filter($fileArray, 'file_exists');

        foreach($fileArray as $file){
            $zip->addFile($file,basename($file));   //向压缩包中添加文件
        }
        $zip->close();  //关闭压缩包
        return $fileName;
    }

    /**
     * 获取用户的已用空间大小
     * @author linyc
     * @param  int       $uid 用户id
     * @param  bool      $needFormat 是否需要格式化
     * @return int  格式化后的剩余可用空间大小
     */
    public static function getUsedSpace($uid, $needFormat = true)
    {
        $where = [
            ['uid', $uid],
            ['disable', 1],
            ['status', 1],
            ['file_type', '>', 1]
        ];
        $usedSpace = Files::where($where)->sum('file_size');
        if ($needFormat) {
            $usedSpace = self::formatSize($usedSpace);
        }
        return $usedSpace;
    }

    /**
     * 格式化文件大小为更人性化的显示方式
     * @author linyc
     * @param  int       $fileSize  文件大小，以B为单位
     * @param  string    $type  转换单位类型， 默认为'auto'， 可选值 'K','M','G','T'
     * @return string
     */
    public static function formatSize($fileSize, $type = 'auto')
    {
        switch ($type) {
            case 'K':
                $result = round($fileSize / 1024, 2) . $type;
                break;
            case 'M':
                $result = round($fileSize / (1024 * 1024), 2) . $type;
                break;
            case 'G':
                $result = round($fileSize / (1024 * 1024 * 1024), 2) . $type;
                break;
            case 'T':
                $result = round($fileSize / (1024 * 1024 * 1024 * 1024), 2) . $type;
                break;
            default:
                if ($fileSize < 1024) {
                    $result = $fileSize . 'B';
                } elseif ($fileSize > (1024 - 1) && $fileSize < (1024 * 1024)) {
                    $result = round($fileSize / 1024, 2) . 'K';
                } elseif ($fileSize > (1024 * 1024 - 1) && $fileSize < (1024 * 1024 * 1024)) {
                    $result = round($fileSize / (1024 * 1024), 2) . 'M';
                } elseif ($fileSize > (1024 * 1024 * 1024 - 1) && $fileSize < (1024 * 1024 * 1024 * 1024)) {
                    $result = round($fileSize / (1024 * 1024 * 1024), 2) . 'G';
                } else {
                    $result = round($fileSize / (1024 * 1024 * 1024 * 1024), 2) . 'T';
                }
                break;
        }
        return $result;
    }

    /**
     * 格式化文件大小为更人性化的显示方式
     * @author linyc
     * @param  int       $directory  目标文件记录id
     * @param  int       $uid  用户id
     * @return bool
     */
    public static function checkDirectory($directory, $uid)
    {
        if (!is_numeric($directory) || $directory < 0) {
            return false;
        }

        if($directory === 0){
            return true;
        }
        $fid = Files::where(['id' => $directory, 'uid' => $uid, 'disable' => 1, 'status' => 1])->value('id');

        if (!$fid) {
            return false;
        }
        return true;
    }

    /**
     * 根据文件全名获取文件名和后缀名
     * @author linyc
     * @param  string    $fileName 文件全名
     * @return array
     */
    public static function getFileData($fileName)
    {
        $fileData = [
            'name' => $fileName,
            'ext' => ''
        ];
        $position = strrpos($fileName, '.');
        if ($position) {
            $fileData['ext'] = substr($fileName, $position + 1);
        }
        if ($fileData['ext']) {
            $fileData['name'] = str_replace('.' . $fileData['ext'], '', $fileName);    // 取出不带后缀名的文件名
        }
        return $fileData;
    }

    /**
     * 根据文件后缀名获取文件类型
     * @author linyc
     * @param  string    $ext 文件后缀名
     * @return string
     */
    public static function getFileType($ext)
    {
        $fileType = 7;  // 其他类型
        foreach (self::$fileType as $k => $v) {
            if (in_array($ext, $v)) {
                $fileType = $k;
            }
        }
        return $fileType;
    }

    /**
     * 指定目标目录后，返回完整的path
     * @author linyc
     * @param  int    $directory 目标目录id
     * @param  int    $uid 用户id
     * @return string
     */
    public static function getEntirePath($directory, $uid)
    {
        if (!$directory) {
            return '0';
        }
        $path = Files::where(['id' => $directory, 'uid' => $uid, 'disable' => 1, 'status' => 1])->value('path');
        return $path . '-' . $directory;
    }

    /**
     * 内存加锁，防止文件夹批量上传时出BUG
     * @author linyc
     * @param  int    $directory 目录id
     * @param  int    $uid 用户id
     * @return string
     */
    public static function lock($directory, $uid)
    {
        $key = $uid . '_' . $directory;
        $redis = Redis::connection('myRedis');
        while (1){
            $check = $redis->setnx($key, 1);
            if ($check) {
                break;
            }
            usleep(5000);  //  挂起5000毫秒
        }
        return true;
    }

    /**
     * 操作完成后，把内存解锁
     * @author linyc
     * @param  int    $directory 目录id
     * @param  int    $uid 用户id
     * @return string
     */
    public static function unlock($directory, $uid)
    {
        $key = $uid . '_' . $directory;
        $redis = Redis::connection('myRedis');
        $result = $redis->del($key);
        return $result;
    }

    /**
     * 根据数据库内的url获取完整下载路径
     * @author linyc
     * @param  string    $url 数据库存储的下载路径
     * @return string
     */
    public static function getUrl($url)
    {
        return 'http://' . $_SERVER['HTTP_HOST'] . '/' . $url;
    }

    /**
     * 根据数据库内的url获取完整下载路径
     * @author fancy
     * @param  string    $id 文件id
     * @return string
     */
    public function get_files($id)
    {

        
    }

}
