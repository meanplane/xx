<?php
/**
 * Aria2 方法封装
 * @filename  Aria2.php
 * @author    linyc
 * @date      2018-9-17 17:25:22
 */
namespace App\Extend;

class Aria2
{
    const SERVER = '120.79.193.155:6800/jsonrpc';
    const DOWNLOAD_DIR = '/data/aria2c/download';
    const RPC_ID = 'Aria2_test';
    const SECRET = '';
    const LOW_NOTICE = '如果您看到此文件，请升级到';

    private $errcode = [
        0 => 'all downloads were successful.',
        1 => 'an unknown error occurred.',
        2 => 'time out occurred.',
        3 => 'a resource was not found.',
        4 => 'aria2 saw the specified number of "resource not found" error.',    // See --max-file-not-found option.
        5 => 'download aborted because download speed was too slow.',    // See --lowest-speed-limit option.
        6 => 'network problem occurred.',
        7 => 'there were unfinished downloads.',    // This error is only reported if all finished downloads were successful and there were unfinished downloads in a queue when aria2 exited by pressing Ctrl-C by an user or sending TERM or INT signal.
        8 => 'remote server did not support resume when resume was required to complete download.',
        9 => 'there was not enough disk space available.',
        10 => 'piece length was different from one in .aria2 control file.',    // See --allow-piece-length-change option.
        11 => 'aria2 was downloading same file at that moment.',
        12 => 'aria2 was downloading same info hash torrent at that moment.',
        13 => 'file already existed.',    // See --allow-overwrite option.
        14 => 'renaming file failed.',    // See --auto-file-renaming option.
        15 => 'aria2 could not open existing file.',
        16 => 'aria2 could not create new file or truncate existing file.',
        17 => 'file I/O error occurred.',
        18 => 'aria2 could not create directory.',
        19 => 'name resolution failed.',
        20 => 'aria2 could not parse Metalink document.',
        21 => 'FTP command failed.',
        22 => 'HTTP response header was bad or unexpected.',
        23 => 'too many redirects occurred.',
        24 => 'HTTP authorization failed.',
        25 => 'aria2 could not parse bencoded file (usually ".torrent" file).',
        26 => '".torrent" file was corrupted or missing information that aria2 needed.',
        27 => 'Magnet URI was bad.',
        28 => 'bad/unrecognized option was given or unexpected option argument was given.',
        29 => 'the remote server was unable to handle the request due to a temporary overloading or maintenance.',
        30 => 'aria2 could not parse JSON-RPC request.',
        // 31    // 'Reserved. Not used.'
        32 => 'checksum validation failed.'
    ];


    private function send($method, $params)
    {
        if (self::SECRET) {
            $data['secret'] = self::SECRET;
        }
        $data['id'] = self::RPC_ID;
        $data['method'] = $method;
        $data['params'] = $params;

        $jsonData = json_encode($data);

        $response = $this->curlPost(self::SERVER, $jsonData);

        if (!empty($response['error'])) {
            return [
                'code' => -1,
                'msg' => $response['error']['message']
            ];
        }
        return $response['result'];
    }

    private function curlPost(string $url, string $param, array $header = [])
    {
        $header = [
            'content-type: application/json',
        ];
        $ch = curl_init();
        $curl_options = [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => 1, //返回原生的（Raw）输出
            CURLOPT_HEADER => 0,
            CURLOPT_TIMEOUT => 120, //超时时间
            CURLOPT_FOLLOWLOCATION => 1, //是否允许被抓取的链接跳转
            CURLOPT_HTTPHEADER => $header,
            CURLOPT_POST => 1, //POST
            CURLOPT_POSTFIELDS => $param, //post数据
            CURLOPT_ENCODING=>'gzip,deflate'
        ];
        if (strpos($url,"https") !== false) {
            $curl_options[CURLOPT_SSL_VERIFYPEER] = false; // 对认证证书来源的检查
        }
        curl_setopt_array($ch, $curl_options);
        $res = curl_exec($ch);
        $data = json_decode($res, true);
        if(json_last_error() != JSON_ERROR_NONE){
            $data = $res;
        }
        curl_close($ch);
        return $data;
    }

    public function addTorrent($url)
    {
        $content = file_get_contents($url);
        $gid = $this->send('aria2.addTorrent', [base64_encode($content), [], ['rpc-save-upload-metadata' => 'false', 'bt-remove-unselected-file' => 'true', 'pause' => 'true']]);
        return $gid;
    }

    public function addUri($url)
    {
//        $url = 'http://download.test.zhangling.link:8021/JX61TarlyWqMRglLi2TftS.png';
//        $url = 'magnet:?xt=urn:btih:40552b0328b4189fd781811f91988a57fdb0b0ba';
        $gid = $this->send('aria2.addUri', [[$url]]);
        return $gid;
    }

    public function tellStopped($offset = 0, $num = 5)
    {
        $result = $this->send('aria2.tellStopped', [$offset, $num]);
    }

    public function remove($gid)
    {
        $result = $this->send('aria2.remove', [$gid]);
    }

    public function pause($gid)
    {
        $result = $this->send('aria2.pause', [$gid]);
    }

    public function unPause($gid)
    {
        $result = $this->send('aria2.unpause', [$gid]);
    }

    public function changeOption($gid, $options)
    {
        $result = $this->send('aria2.changeOption', [$gid, $options]);
        if ($result != 'OK') {
            return [
                'code' => -1,
                'msg' => '操作失败'
            ];
        }
        return $result;
    }

    public function tellStatus($gid, $keys = [])
    {
        $result = $this->send('aria2.tellStatus', [$gid]);
        if (!in_array($result['errorCode'], [0, 11, 12, 13])) {
            return [
                'code' => $result['errorCode'],
                'msg' => $this->errcode[$result['errorCode']]
            ];
        }
        return $result;
    }

}